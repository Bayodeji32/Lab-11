#include <iostream>
#include "sphericalBlocks.h"
#include <vector>
#include <cmath>
#define M_PI   3.14159265
#include <algorithm>

using namespace std;

vector<vector<int> > sphericalBlocks::spherical(vector<vector<int> > &block)
{
 for (vector<int> row : block){
 	
		int w=row[0];
		int h=row[1];
		int l=row[2];
		int surfaceArea=(4*M_PI*(w/2)*(w/2));
		int volume=(4/3)*M_PI*(w/2)*(w/2)*(w/2);
		vector<int> coord;
coord.push_back(w);
coord.push_back(surfaceArea);
coord.push_back(volume);
blocks.push_back(coord);
sort(blocks.begin(),blocks.end());

}
	
	return blocks;
}
void sphericalBlocks::spherePrint(){
	for (vector<int> row : blocks){
 	
		int w=row[0];
		int h=row[1];
		int l=row[2];
		
	cout<<w<<"  "<<h<<"  "<<l<<endl;
}
}

