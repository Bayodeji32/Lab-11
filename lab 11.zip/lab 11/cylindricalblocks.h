#include <iostream>
#include <vector>
#include "sqrBaseRectBlocks.h"
#ifndef CYLINDRICALBLOCKS_H
#define CYLINDRICALBLOCKS_H


class cylindricalBlocks: public sqrBaseRectBlocks
{
    public:
        int width;
        int height;
        int length;
        vector<vector<int> > blocks;
        vector<vector<int> >cylindrical(vector<vector<int> > &block);
        void printCylindrical();
};

#endif // CYLINDRICALBLOCKS_H
