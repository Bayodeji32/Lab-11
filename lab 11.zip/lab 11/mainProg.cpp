#include <iostream>
#include "rectBlocks.cpp"
#include "sqrBaseRectBlocks.cpp"
#include "cuboidBlocks.cpp"
#include "cylindricalblocks.cpp"
#include "sphericalBlocks.cpp"
#include <vector>
#include <fstream>

using namespace std;

int main(){
	rectBlocks r;
	sphericalBlocks sp;
	sqrBaseRectBlocks sq;
	cylindricalBlocks cy;
	cuboidBlocks cu;
	vector<vector<int> > rectangles=r.rect();
	vector<vector<int> > sqrBlocks=sq.sqrBlocks(rectangles);
	vector<vector<int> > cuboidBlocks=cu.cuboid(sqrBlocks);
	vector<vector<int> > cylinBlocks=cy.cylindrical(sqrBlocks);
	vector<vector<int> > sphBlocks=sp.spherical(cuboidBlocks);
	//sp.spherePrint();
	cy.printCylindrical();
 
	return 0;
}
