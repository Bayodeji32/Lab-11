#include <iostream>
#include "cylindricalblocks.h"
#include <vector>
#include <cmath>
#define M_PI   3.14159265
#include <algorithm>

vector<vector<int> > cylindricalBlocks::cylindrical(vector<vector<int> > &block)
{
	 for (vector<int> row : block){
    int w=row[0];
		int h=row[1];
		int l=row[2];
		int surfaceArea=2*M_PI*(w/2)*h;
		int volume=M_PI*(w/2)*(w/2)*h;
		int area=2*M_PI*(w/2)*h+2*M_PI*(w/2)*(w/2);
		vector<int> coord;
coord.push_back(surfaceArea);
coord.push_back(w);
coord.push_back(l);
coord.push_back(area);
blocks.push_back(coord);
sort(blocks.begin(),blocks.end());
		
	}
	return blocks;
}
void cylindricalBlocks::printCylindrical(){
	for (vector<int> row : blocks){
 	
		int w=row[0];
		int h=row[1];
		int l=row[2];
		
	cout<<w<<"  "<<h<<"  "<<l<<endl;
}
}

