#include <iostream>
#include <vector>
#ifndef RECTBLOCKS_H
#define RECTBLOCKS_H

using namespace std;

class rectBlocks
{
      public:
        int width;
        int height;
        int length;
        vector<vector<int> > blockVect;
		vector<vector<int> > rect();
		void printVect();

};

#endif // RECTBLOCKS_H
