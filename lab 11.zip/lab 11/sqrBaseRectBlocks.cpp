#include <iostream>
#include "sqrBaseRectBlocks.h"
#include <vector>

using namespace std;

vector<vector<int> > sqrBaseRectBlocks::sqrBlocks(vector<vector<int> > &block)
{
	
    for (vector<int> row : block){
		int w=row[0];
		int h=row[1];
		int l=row[2];
		if (w==h){
vector<int> coord;
coord.push_back(w);
coord.push_back(h);
coord.push_back(l);
blocks.push_back(coord);
		}
		
	}
	return blocks;
}

