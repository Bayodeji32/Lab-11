#include <iostream>
#include <vector>
#include "rectBlocks.h"
#ifndef SQRBASERECTBLOCKS_H
#define SQRBASERECTBLOCKS_H

using namespace std;
class sqrBaseRectBlocks :public rectBlocks
{
      public:
        int width;
        int height;
        int length;
        vector<vector<int> > blocks;
        vector<vector<int> >sqrBlocks(vector<vector<int> > &block);
		

};

#endif // SQRBASERECTBLOCKS_H
