#include <iostream>
#include "rectBlocks.h"
#include <vector>
#include <fstream>

using namespace std;
vector<vector<int> > rectBlocks::rect()
{
ifstream inPutLineFile;
inPutLineFile.open("dataBlocks.dat");
if(inPutLineFile.fail()){
	cerr<<"Error opening file"<<endl;
	exit(1);
}

for (int j=0;j<20;j++){
	vector<int> block;
for(int i=0;i<1;i++ ){
	
	int w;
	int h;
	int l;
	inPutLineFile>>w>>h>>l;
width=w;
height=h;
length=l;

block.push_back(w);
block.push_back(h);
block.push_back(l);

}
blockVect.push_back(block);

};
inPutLineFile.close();
return blockVect;
}

void rectBlocks::printVect(){
	for (vector<int> row : blockVect){
		int w=row[0];
		int h=row[1];
		int l=row[2];
		cout<<w<<"  "<<h<<"  "<<l<<endl;
	}
	
}

