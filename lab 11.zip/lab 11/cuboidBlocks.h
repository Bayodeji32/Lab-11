#include <iostream>
#include <vector>
#include "sqrBaseRectBlocks.h"
#ifndef CUBOIDBLOCKS_H
#define CUBOIDBLOCKS_H


class cuboidBlocks:public sqrBaseRectBlocks
{
    public:
        int width;
        int height;
        int length;
        vector<vector<int> > blocks;
        vector<vector<int> >cuboid(vector<vector<int> > &block);
};

#endif // CUBOIDBLOCKS_H
