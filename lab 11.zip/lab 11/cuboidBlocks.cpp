#include <iostream>
#include "cuboidBlocks.h"
#include <vector>

vector<vector<int> > cuboidBlocks::cuboid(vector<vector<int> > &block)
{
    for (vector<int> row : block){
		int w=row[0];
		int h=row[1];
		int l=row[2];
		if (w==h && h==l && w==l){
vector<int> coord;
coord.push_back(w);
coord.push_back(h);
coord.push_back(l);
blocks.push_back(coord);
		}
		
	}
	return blocks;
}
	

