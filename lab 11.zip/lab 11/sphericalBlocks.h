#include <iostream>
#include <vector>
#include "cuboidBlocks.h"
#ifndef SPHERICALBLOCKS_H
#define SPHERICALBLOCKS_H


class sphericalBlocks: public cuboidBlocks
{
	public:
        int width;
        int height;
        int length;
        vector<vector<int> > blocks;
        vector<vector<int> >spherical(vector<vector<int> > &block);
        vector<vector<int> >calcSphere(vector<vector<int> > &block);
        void spherePrint();
};

#endif // SPHERICALBLOCKS_H
